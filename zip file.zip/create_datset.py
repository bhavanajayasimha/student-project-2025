import pandas as pd
import numpy as np

np.random.seed(42)
n_rows = 500

genders = np.random.choice(['Male', 'Female'], size=n_rows)
married = np.random.choice(['Yes', 'No'], size=n_rows, p=[0.7, 0.3])
dependents = np.random.choice(['0', '1', '2', '3+'], size=n_rows)
education = np.random.choice(['Graduate', 'Not Graduate'], size=n_rows, p=[0.7, 0.3])
self_emp = np.random.choice(['Yes', 'No'], size=n_rows, p=[0.2, 0.8])
property_area = np.random.choice(['Urban', 'Semiurban', 'Rural'], size=n_rows, p=[0.4, 0.35, 0.25])

# big financial values
applicant_income = np.random.randint(20000, 150000, size=n_rows)
coapplicant_income = np.random.randint(0, 120000, size=n_rows)
loan_amount = np.random.randint(300000, 5000000, size=n_rows)
loan_term = np.random.choice([60, 120, 180, 240, 300, 360], size=n_rows)
credit_history = np.random.choice([0.0, 1.0], size=n_rows, p=[0.3, 0.7])

loan_status = []
for inc, co_inc, loan, ch in zip(applicant_income, coapplicant_income, loan_amount, credit_history):
    total_income = inc + co_inc
    emi_ratio = loan / (total_income + 1)
    if ch == 1.0 and emi_ratio < 45_000:
        loan_status.append('Y')
    elif ch == 1.0 and emi_ratio < 65_000 and total_income > 70000:
        loan_status.append('Y')
    else:
        loan_status.append('N')

df = pd.DataFrame({
    'Loan_ID': [f'LB{100000+i}' for i in range(n_rows)],
    'Gender': genders,
    'Married': married,
    'Dependents': dependents,
    'Education': education,
    'Self_Employed': self_emp,
    'ApplicantIncome': applicant_income,
    'CoapplicantIncome': coapplicant_income,
    'LoanAmount': loan_amount,
    'Loan_Amount_Term': loan_term,
    'Credit_History': credit_history,
    'Property_Area': property_area,
    'Loan_Status': loan_status
})

df.to_csv("train.csv", index=False)
print("Dataset created successfully → train.csv")