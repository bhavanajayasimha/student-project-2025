import pandas as pd
import joblib

# Load saved model
model = joblib.load("loan_model.pkl")

print("------ Loan Approval Prediction ------")

# Collect input from user
Gender = input("Gender (Male/Female): ")
Married = input("Married (Yes/No): ")
Dependents = input("Dependents (0/1/2/3+): ")
Education = input("Education (Graduate/Not Graduate): ")
Self_Employed = input("Self Employed (Yes/No): ")
ApplicantIncome = float(input("Applicant Income: "))
CoapplicantIncome = float(input("Coapplicant Income: "))
LoanAmount = float(input("Loan Amount: "))
Loan_Amount_Term = float(input("Loan Amount Term: "))
Credit_History = float(input("Credit History (1 or 0): "))
Property_Area = input("Property Area (Urban/Semiurban/Rural): ")

# Create dataframe for model
applicant = {
    'Gender': Gender,
    'Married': Married,
    'Dependents': Dependents,
    'Education': Education,
    'Self_Employed': Self_Employed,
    'ApplicantIncome': ApplicantIncome,
    'CoapplicantIncome': CoapplicantIncome,
    'LoanAmount': LoanAmount,
    'Loan_Amount_Term': Loan_Amount_Term,
    'Credit_History': Credit_History,
    'Property_Area': Property_Area
}

df = pd.DataFrame([applicant])

# Predict
pred = model.predict(df)[0]
proba = model.predict_proba(df)[0][1]

print("\nPrediction Probability:", round(proba, 3))
print("Loan Approved?" , "YES" if pred == 1 else "NO")